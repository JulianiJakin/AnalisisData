# Dicoding Collection Dashboard ✨

## Setup environment
```
conda create --machinelearning python=3.9
conda activate machinelearning
pip install numpy pandas scipy matplotlib seaborn jupyter streamlit
```

## Run steamlit app
```
streamlit run dashboard.py
```

